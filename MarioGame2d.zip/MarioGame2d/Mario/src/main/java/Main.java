import java.awt.*;
import jade.Window;

public class Main {
    public static void main(String[] args){
        Window window = new Window.get();
        window.run();
    }
}
